export const ProductReducer = (state, action) => {

   switch(action.type){
           default:
           return [...state];
   }

}